//dlt2hc Daniel Tran 
//Credits to Google for latefee
import java.util.ArrayList;
import java.util.*;
import java.lang.Object;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.*;

public class Library {
	private ArrayList<Book> libraryBooks;
	private ArrayList<Person> patrons;
	private String name;
	private int numBooks;
	private int numPeople;
	private String currentDate;

	public Library(String name) {
		this.name=name;
		patrons= new ArrayList<Person>();
		libraryBooks= new ArrayList<Book>();
		this.currentDate=new SimpleDateFormat("dd MM yyyy").format(Calendar.getInstance().getTime());
	}
	public ArrayList<Book> getLibraryBooks() {
		return libraryBooks;
	}

	public ArrayList<Person> getPatrons() {
		return patrons;
	}

	public String getName() {
		return name;
	}

	public int getNumBooks() {
		return numBooks;
	}

	public int getNumPeople() {
		return numPeople;
	}

	public String getCurrentDate() {
		return currentDate;
	}

	public void setLibraryBooks(ArrayList<Book> libraryBooks) {
		this.libraryBooks = libraryBooks;
	}

	public void setPatrons(ArrayList<Person> patrons) {
		this.patrons = patrons;
	}

	public void setName(String name) {
		this.name = name;
	}


	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
	public int checkNumCopies( String title, String author) {
		int numb=0;
		for(int i =0; i < this.libraryBooks.size(); i++) {
			if (libraryBooks.get(i).getTitle()==title&libraryBooks.get(i).getAuthor()==author) {
				numb++;
			}
		}
		return numb;
	}
	public int totalNumBooks() {
		//		int numbooks=0;
		//		for (int i =0; i < patrons.size();i++) {
		//			numbooks+=patrons.get(i).getCheckedOut().size();
		//		}
		return libraryBooks.size();
	}
	public boolean checkOut(Person p, Book b, String dueDate) {
		if (this.patrons.contains(p)&&!(b.isCheckedOut())) {
			for (int i=0;i<libraryBooks.size();i++) {
				if (libraryBooks.get(i).equals(b)) {
					p.addBook(this.libraryBooks.get(this.libraryBooks.indexOf(b)));
//					p.getCheckedOut().get(i).setCheckedOut(true);
					this.libraryBooks.get(this.libraryBooks.indexOf(b)).setdueDate(dueDate);
					this.libraryBooks.get(this.libraryBooks.indexOf(b)).setCheckedOut(true);
					return true;	
				}

			}
		}
		return false;
	}
	public ArrayList<Book> booksDueOnDate(String date){
		ArrayList<Book> numdue= new ArrayList<Book>();
		for (int i=0;i<libraryBooks.size();i++) {
			if(libraryBooks.get(i).getdueDate()==date) {
				numdue.add(libraryBooks.get(i));
			}
		}
		return numdue;
	}
	public double lateFee(Person p) {
		double totalfee=0;
		int daysOver=0;
		Date current;
		DateFormat myFormat= new SimpleDateFormat("dd MM yyyy");
		try {
			current= myFormat.parse(getCurrentDate());
			Date dueDate;
			ArrayList<Double> fees= new ArrayList<Double>();
			int days;
			long diff;
			for (int i=0; i<p.getCheckedOut().size();i++) {
				dueDate= myFormat.parse(p.getCheckedOut().get(i).getdueDate());
				diff= current.getTime()-dueDate.getTime();
				days= (int)(diff/(1000*60*60*24));
				if (diff>0) {
					daysOver+=days;
					fees.add(daysOver*p.getCheckedOut().get(i).getBookValue());
				}
			}
			for (double overDue: fees) {
				totalfee+= .01*overDue;
			}
			return totalfee;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return totalfee;
	}


	public String toString() {
		return "Library: "+ this.name+" Patrons: "+this.patrons+ " Books: "+libraryBooks;
	}
	public static void main(String args[]) {
		Library lib= new Library("FFC");
		Book book1= new Book("Harry Potter", "Rowling", 2453, 19.99);
		Book book2= new Book("Prisoner of Azkaban", "Rowling",34444, 25.99);
		Book book3= new Book("Chamber", "Rowling",108898, 18.99);
		Book book4= new Book("Order", "Rowling", 8938762, 20.00);
		Book book5= new Book("Harry Potter", "Rowling", 2454, 19.99);
		Book book6= new Book("Harry Potter", "Rowling", 2455, 19.99);
		Book book7= new Book("Harry Potter", "Rowling", 2456, 19.99);

		Person personone=new Person("Bill", "Northwyck Ct.",123);
		ArrayList<Person> customers= new ArrayList<Person>();
		customers.add(personone);
		lib.setPatrons(customers);
		ArrayList<Book> group= new ArrayList<Book>();
		group.add(book1);
		group.add(book2);
		group.add(book3);
		group.add(book4);
		group.add(book5);
		group.add(book6);
		group.add(book7);
		//		System.out.println(personone.addBook(book1));
		//		System.out.println(book1.isCheckedOut());
		//		lib.setLibraryBooks(group);
		//		System.out.println(lib);
		//		System.out.println(lib.checkNumCopies("Harry Potter", "Rowling"));
		//		System.out.println(lib.totalNumBooks());
		//		lib.checkOut(personone, book6, "30 2 2018");
		//		System.out.println(lib.checkNumCopies("Harry Potter", "Rowling"));
		//		System.out.println(lib);
		//		System.out.println(lib.checkOut(personone, book6, "30 2 2018"));
		lib.setLibraryBooks(group);
		lib.checkOut(personone, book1, "13 02 2018");
		System.out.println(personone.getCheckedOut());
		System.out.println(lib.lateFee(personone));
//		System.out.println(lib.totalNumBooks());



	}
}
