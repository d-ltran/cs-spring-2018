//Daniel Tran dlt2hc Homework 2
import java.util.ArrayList;
import java.util.*;
public class Person {
	private String name;
	private ArrayList<Book> checkedOut;
	private String address;
	private int libraryCardNum;

	public Person(String name, String address, int libraryCardNum) {
		this.name=name;
		this.address=address;
		checkedOut= new ArrayList<Book>();
		this.libraryCardNum=libraryCardNum;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name=name;
	}

	public ArrayList<Book> getCheckedOut() {
		return checkedOut;
	}
	public void setCheckedOut(ArrayList<Book> checkedOut) {
		this.checkedOut = checkedOut;
	}
	public boolean addBook(Book b) {
		if (this.checkedOut.contains(b))
			return false;
		else {
			this.checkedOut.add(b);
			
			return true;
		}
	}
	public boolean hasRead(Book b) {
		if (this.checkedOut.contains(b))
			return true;
		else {

			return false;
		}
	}
	public boolean forgetBook(Book b) {
		if (this.checkedOut.contains(b)) {
			this.checkedOut.remove(b);
			return true;
		}
		else
			return false;

	}
	public int numBooksRead() {
		return checkedOut.size();
	}
	public boolean equals(Object o) {
		if (o instanceof Person && this.libraryCardNum==((Person)o).getLibraryCardNum()) {
			return true;
		}
		else
			return false;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getLibraryCardNum() {
		return libraryCardNum;
	}
	public void setLibraryCardNum(int libraryCardNum) {
		this.libraryCardNum = libraryCardNum;
	}
	public String toString() {
		return "Name: "+this.name+", Library Card Number: "+this.libraryCardNum+", Books CheckedOut: "+this.checkedOut;
	}
	public static ArrayList<Book> commonBooks(Person a, Person b){
		ArrayList<Book> common= new ArrayList<Book>();
		Book bookat_a;
		for (int i=0; i< a.numBooksRead();i++) {
			bookat_a=a.getCheckedOut().get(i);
			if (b.getCheckedOut().contains(bookat_a)){
				common.add(bookat_a);
			}
		}

		return common;
	}

	public static double similarity(Person a, Person b) {
		double commonbooks=(double)commonBooks(a, b).size();
		double min=Math.min((double)a.numBooksRead(), (double)b.numBooksRead());
		if (a.numBooksRead()==0||b.numBooksRead()==0)
			return 0.0;
		else
			return commonbooks/min;

	}
	public static void main(String args[]) {
		Person personone=new Person("Bill", "Northwyck Ct.",123);
		Person persontwo=new Person("Joe", "Hollywood " ,321);
		Person personthree= new Person("Kaneki Ken","McLean", 435);
		Book book1= new Book("Harry Potter", "Rowling", 2453, 19.99);
		Book book2= new Book("Prisoner of Azkaban", "Rowling",34444, 25.99);
		Book book3= new Book("Chamber", "Rowling",108898, 18.99);
		Book book4= new Book("Order", "Rowling", 8938762, 20.00);
		Book book5= new Book("Hollows", "Rowling",1356804, 39.99);
		personone.addBook(book1);
		personone.addBook(book2);
		personone.addBook(book3);
		persontwo.addBook(book4);
		persontwo.addBook(book1);
		persontwo.addBook(book2);
		persontwo.addBook(book3);
		System.out.println(book1);
		System.out.println(personone.getCheckedOut());




	}

}


