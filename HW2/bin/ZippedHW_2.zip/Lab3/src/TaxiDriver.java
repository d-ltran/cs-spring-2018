
public class TaxiDriver {

	public static void main(String args[]) {
		String anExpression = "1+*3";
		String expressi2 = "12 43";
		String expressi3 = "13 *";
		String expressi4 = "12 * x";
		String expressi5 = "abc";
		int count=0;
		// a String that may or may not be an expression
		
		
		for (int i=0; i<37;i++) {
			boolean valid = Expression.isValid(i, anExpression);
			if (valid==true) {
				System.out.println("Method #"+(i+1)+" has errors! Two operators are trying to be executed simultaneously!");
				count++;
			}
			boolean valid1 = Expression.isValid(i, expressi2);
			if (valid1==true) {
				System.out.println("Method #"+(i+1)+" has errors! Two grouped w/o operators!");
				count++;
			}boolean valid2 = Expression.isValid(i, expressi3);
			if (valid2==true) {
				System.out.println("Method #"+(i+1)+" has errors! Operator lacks one value!");
				count++;
			}boolean valid3 = Expression.isValid(i, expressi4);
			if (valid3==true) {
				System.out.println("Method #"+(i+1)+" has errors! Number multiplied by character!");
				count++;
			}boolean valid4 = Expression.isValid(i, expressi5);
			if (valid4==true) {
				System.out.println("Method #"+(i+1)+" has errors! Just a list of characters!");
				count++;
			}
			
		}
	}
}
