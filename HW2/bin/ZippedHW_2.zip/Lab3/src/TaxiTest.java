import org.junit.*;
import static org.junit.Assert.*;
import org.junit.Test;


public class TaxiTest {
	private Taxi t = new Taxi(12.00, 5);
	//calculateFare() test #1
	@Test(timeout=100)
	public void testPickUpSuccess() {
		assertTrue(t.pickUp(5));
	}

	//calculateFare() test #2
	@Test(timeout=100)
	public void testCalculateFare() {
		/*
		 * Your test implementation goes here.
		 */
		assertTrue(t.calculateFare(0, 0) == 0.0 );

	}

	//pickUp() test #1
	@Test(timeout=100)
	public void testPickUpEnoughRoomwhenFalse() {

		assertFalse(t.pickUp(6));
	}

	public void testPickUpEnoughRoomwhenTrue() {
		/*	
		 * Make sure pickUp() returns true when you try to pick up some
		 * number of passengers within capacity.
		 */
		assertTrue(t.pickUp(5));
	}
	public static void main(String args[]) {
		int whichVersion = 18;         		// a number such that 0 <= whichVersion < 37
		String anExpression = "1+*3";  	        // a String that may or may not be an expression
		boolean valid = Expression.isValid(whichVersion, anExpression);
	}
}
