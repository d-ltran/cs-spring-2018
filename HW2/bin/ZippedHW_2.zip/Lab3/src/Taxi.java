//

public class Taxi {

	private double rate;
	private int capacity;
	private int passengers;


	public Taxi() { // NO-ARGUMENT CONSTRUCTOR
		/*
		 * Initialize global fields.
		 * These values will never be changed because the constructor has no parameters.
		 */
		this.capacity=5;
		rate=.1;
		passangers=0;


	}

	public Taxi(double rate, int capacity) {
		/*
		 * Initialize global fields.
		 * These values can be changed via constructor parameters.
		 */
		this.rate=rate;
		this.capacity=capacity;
		this.passengers=0;

	}

	public double calculateFare(int passengersLeaving, int durationOfRide) {
		/*
		 * Your method implementation goes here.
		 */
		return ((double)passengersLeaving * 1.5) + ((double)durationOfRide*.1);

	}

	public boolean pickUp(int passengersLoading) {
		/*
		 * Your method implementation goes here.
		 */
		int emptyspace= capacity-passengers;
		if (emptyspace>= passengersLoading) {
			this.passengers+=passengersLoading;
			return true;
		}
		else {
			return false;
		}

	}

}
